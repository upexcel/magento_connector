export interface User {
    password: string;
    newPassword: string;
    confirmPassword: string;
}