import {Component, OnInit, Input} from '@angular/core';
import {CategoryListDataType} from '../../model/home/categorylistDataType';
import {CategoryList} from '../../model/home/categoryList';
import {MenuController, NavController} from 'ionic-angular';
import {CategoryProductPage} from '../../pages/categoryProduct/categoryProduct';
import forEach from 'lodash/forEach';
import {FilterService} from './../../providers/filter-service/filterService';

@Component({
    selector: 'sidemenu',
    templateUrl: 'sidemenu.html'
})
export class SideMenu implements OnInit {
    @Input() token: any;
    data: CategoryListDataType;
    public rootPage: any;
    public access_token;
    public usermenu: boolean;
    constructor(private _filterService: FilterService, private _categoryList: CategoryList, private _menuCtrl: MenuController, private _navCtrl: NavController) {}
    ngOnInit() {
        this._menuCtrl.enable(true);
        this.categoryList();
    }

    /*
  *categoryList
  *calling service for get category list
  */
    categoryList() {
        this._categoryList.getCategoryList().then((res) => {
            if (res) {
                forEach(res['body'].children, (value) => {
                    forEach(value['children'], (children) => {
                        children['showDetails'] = false;
                        if (children.include_in_menu == "true") {
                            if (children.children.length == 0) {
                                if (children.display_mode != "PAGE") {
                                    children['show'] = true;
                                } else {
                                    children['show'] = false;
                                }
                            } else {
                                children['show'] = true;
                                forEach(children.children, (val) => {
                                    if (val.include_in_menu == "true") {
                                        if (val.children.length == 0) {
                                            if (val.display_mode != "PAGE") {
                                                val['show'] = true;
                                            } else {
                                                val['show'] = false;
                                            }
                                        } else {
                                            val['show'] = true;

                                        }
                                    }else{
                                        children['show'] = false; 
                                    }
                                })
                            }
                        } else {
                            children['show'] = false;
                        }
                    })
                })
                this.data = res;
            }
        });
    }

    gotoCategoryProduct(gchild_id: any, gchild_name: any, display_mode: any) {
        setTimeout(() => {
            forEach(this.data['body'].children, (value) => {
                forEach(value['children'], (children) => {
                    children['showDetails'] = false;
                    children['icon'] = 'ios-add-circle-outline';
                })
            })
        }, 100);
        this._menuCtrl.close();
        this._filterService.resetFilterData();
        this._navCtrl.push(CategoryProductPage, {"id": gchild_id, "name": gchild_name, "display_mode": display_mode});
    }
    toggle(_toggleData) {
        if (_toggleData.children.length > 0) {
            if (_toggleData.showDetails) {
                _toggleData.showDetails = false;
                _toggleData.icon = 'ios-add-circle-outline';
            } else {
                _toggleData.showDetails = true;
                _toggleData.icon = 'ios-remove-circle-outline';
            }
        }
        else {
            this._menuCtrl.close();
            this._navCtrl.push(CategoryProductPage, {"id": _toggleData.id, "name": _toggleData.name, "display_mode": _toggleData.display_mode});
        }

    }

}
