export class ForgotDataType {
    data: string;
    message: string;
    status: string;
}
