export class ChangePwdDataType {
    data: string
    status: number
    message: string
}
