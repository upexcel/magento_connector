export class MyAccountAddressDataType {
    "body"?: [
        {
            "entity_id"?: string,
            "firstname"?: string,
            "lastname"?: string,
            "company"?: string,
            "city"?: string,
            "country_id"?: string,
            "region"?: string,
            "postcode"?: number,
            "telephone": any,
            "fax"?: any,
            "region_id"?: any,
            "street"?: Array<any>,
            "default_billing"?: number,
            "default_shipping"?: number
        }
    ];
    "status"?: number;
    "message"?: string;
}
