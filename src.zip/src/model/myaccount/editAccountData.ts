export class EditAccountDataType {
    "data": string;
    "status": number;
    "message"?: any;
}
