export class SocialAccountDataType {

}