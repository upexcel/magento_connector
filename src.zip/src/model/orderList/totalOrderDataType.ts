export class TotalOrderDataType {
    body: {
        total_order?: number,
        total_amount?: string
    };
    status?: number;
    message?: string;
    statuscode?: number;
}
