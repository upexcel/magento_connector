export class OrderListDataType {
    "body": {
        "order_id"?: string,
        "grand_total"?: string,
        "created_at"?: any,
        "status"?: string
    };
    "status": number;
    "message": string;
}
