export class GetRating {
    body: {
        max_review: number;
        attribute: any,
        options: any
    }
    status: number
    message: string
} 
