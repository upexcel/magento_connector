export class notifyDatatype {
    body: ''
    status: number
} 
