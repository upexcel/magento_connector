export class SubmitReviewDataType {
    body: {
        review_status: string
    }
    status: number
    message: string
}