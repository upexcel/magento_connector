export class SliderDataType {
    body:{url:any};
    status: number;
    message: string;
}
