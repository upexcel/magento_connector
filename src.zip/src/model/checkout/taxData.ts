export class TaxDataType {
    "body": {
        "discount": number,
        "tax": number
    }
    "status": number;
}