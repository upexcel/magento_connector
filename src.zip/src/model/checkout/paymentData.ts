export class paymentDataType {
    "body": { "payment_methods": { "checkmo": string }, "error": any }
    "status": number;
}