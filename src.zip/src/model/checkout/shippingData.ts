export class shippingDataType {

    "body": {
        "success": boolean,
        "shipping_methods": any
    };
    "status": number
}